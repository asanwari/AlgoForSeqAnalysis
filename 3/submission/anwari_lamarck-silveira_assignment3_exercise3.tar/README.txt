To Execute on console:
py anwari_lamarck-silveira_assignment3_exercise3.py <text> 

Example:
py anwari_lamarck-silveira_assignment3_exercise3.py ABACABA$

Note: This gives output on the console, as shown in the assignment file.