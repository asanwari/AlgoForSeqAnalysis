To Execute on console:
py anwari_lamarck-silveira_assignment2_exercise3.py <pattern> <filename>

Example:
py anwari_lamarck-silveira_assignment2_exercise3.py AAAA input.txt

Note: This gives output on the console, as shown in the assignment file.