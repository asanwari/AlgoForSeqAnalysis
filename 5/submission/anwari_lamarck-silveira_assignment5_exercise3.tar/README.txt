To Execute on console:
py anwari_lamarck-silveira_assignment5_exercise3.py <pattern> <inputFile>.txt <maxDist> 

Example:
py anwari_lamarck-silveira_assignment5_exercise3.py AATT input.txt 1

Note: This gives output on the console, as shown in the assignment file.